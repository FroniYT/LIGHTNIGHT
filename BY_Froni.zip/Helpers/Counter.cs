﻿namespace nitrostealer
{
    class Counting
    {
        public static int Passwords = 0;
        public static int CreditCards = 0;
        public static int AutoFill = 0;
        public static int Cookies = 0;
        public static int History = 0;
        public static int Bookmarks = 0;
        public static int Downloads = 0;
        public static int Discord = 0;
        public static int FileGrabber = 0;
        public static int Telegram = 0;
    }
}
