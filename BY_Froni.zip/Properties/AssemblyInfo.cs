﻿using System.Resources;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Guaginia Spoofer")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Guaginia Inc.")]
[assembly: AssemblyProduct("Colorful Guaginia Spoofer")]
[assembly: AssemblyCopyright("Guaginia © 2021")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]

[assembly: Guid("3b0e2d3d-3d66-42bb-8f9c-d6e188f359ae")]

[assembly: AssemblyVersion("1.3.3.7")]
[assembly: AssemblyFileVersion("1.3.3.7")]
[assembly: NeutralResourcesLanguage("ru")]
